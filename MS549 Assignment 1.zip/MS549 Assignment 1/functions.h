#pragma once
int addition(int a, int b);
int subtraction(int a, int b);
int multiplication(int a, int b);
double division(double a, double b);
void showMenu();

